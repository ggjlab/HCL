#include "ThreadControl.h"

ThreadControl::ThreadControl() {
    chunkInN=0;
    chunkOutN=0;
//     chunkOutBAMposition=new uint [MAX_chunkOutBAMposition];
};