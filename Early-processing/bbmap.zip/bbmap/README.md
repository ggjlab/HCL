# BBTools bioinformatics tools, including BBMap.
# Author: Brian Bushnell, Jon Rood
# Language: Java
# Information about documentation is in /docs/readme.txt.
# Version 35.85
