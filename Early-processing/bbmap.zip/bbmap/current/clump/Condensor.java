package clump;

import java.util.ArrayList;

import stream.Read;

/**
 * @author Brian Bushnell
 * @date Nov 7, 2015
 *
 */
public class Condensor {
	
	public Condensor(){
		
	}
	
	public ArrayList<Clump> makeClumps(ArrayList<Read> list){
		throw new RuntimeException();
	}
	
	public ArrayList<Read> condense(ArrayList<Read> list){
		
		throw new RuntimeException();
	}
	
}
