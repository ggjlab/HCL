package clump;

import kmer.KmerTableSet;

/**
 * @author Brian Bushnell
 * @date Nov 12, 2015
 *
 */
public class ClumpTools {
	
	public static KmerTableSet table=null;
	
}
